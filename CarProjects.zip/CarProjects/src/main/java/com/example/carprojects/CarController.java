package com.example.carprojects;


import jakarta.annotation.Resource;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import javax.sql.DataSource;
import java.io.IOException;

import java.util.List;

@WebServlet("/CarController")
public class CarController extends HttpServlet {

    private CarDBUtil carDBUtil;

    @Resource(name = "jdbc/Cars")
    private DataSource dataSource;

    @Override
    public void init() throws ServletException {
        super.init();

        // create our student db util ... and pass in the conn pool / datasource
        try {
            carDBUtil = new CarDBUtil(dataSource);
        } catch (Exception exc) {
            throw new ServletException(exc);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {
            // read the "command" parameter
            String theCommand = request.getParameter("command");
            // if the command is missing, then default to listing students
            if(theCommand == null)
                theCommand = "list";
            // route to the appropriate method
            switch (theCommand) {
                case "ADD":
                    addCar(request, response);
                    break;
                case "LOAD":
                    loadCar(request, response);
                    break;
                case "UPDATE":
                    updateCar(request, response);
                    break;
                case "DELETE":
                    deleteCar(request, response);
                    break;
                default:
                    listCar(request, response);
            }

        } catch (Exception exc) {
            throw new ServletException(exc);
        }

    }

    private void deleteCar(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        // read student id from form data
        String theCarId = request.getParameter("carId");

        // delete student from database
        carDBUtil.deleteCar(theCarId);

        // send them back to "list students" page
        listCar(request, response);
    }

    private void updateCar(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        // read student info from form data
        int id = Integer.parseInt(request.getParameter("carId"));
        String name = request.getParameter("name");
        String model = request.getParameter("model");
        String year = request.getParameter("year");

        // create a new student object
        Car theCar = new Car(id, name, model, year);

        // perform update on database
        carDBUtil.updateCar(theCar);

        // send them back to the "list students" page
        listCar(request, response);

    }

    private void loadCar(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        // read student id from form data
        String theCarId = request.getParameter("carId");

        // get student from database (db util)
        Car theCar = carDBUtil.getCar(theCarId);

        // place student in the request attribute
        request.setAttribute("THE_CAR", theCar);

        // send to jsp page: update-student-form.jsp
        RequestDispatcher dispatcher =
                request.getRequestDispatcher("/update-car.jsp");
        dispatcher.forward(request, response);
    }

    private void addCar(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // read car info from form data
        String name = request.getParameter("name");
        String model = request.getParameter("model");
        String year = request.getParameter("year");

        // Check if any required field is empty
        if (name == null || name.isEmpty() || model == null || model.isEmpty() || year == null || year.isEmpty()) {
            // Handle the case where fields are empty (e.g., show error message)
            // For simplicity, you can redirect or show an error message to the user
            response.sendRedirect(request.getContextPath() + "/add-car.jsp"); // Redirect back to add-car.jsp
            return;
        }

        // create a new car object
        Car theCar = new Car(name, model, year);

        // add the car to the database
        carDBUtil.addCar(theCar);

        // send back to main page (the car list)
        listCar(request, response);
    }


    private void listCar(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        // get students from db util
        List<Car> cars = carDBUtil.getCar();

        // add students to the request
        request.setAttribute("LIST_CAR", cars);

        // send to JSP page (view)
        RequestDispatcher dispatcher = request.getRequestDispatcher("/car-list.jsp");
        dispatcher.forward(request, response);
    }
}
